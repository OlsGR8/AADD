package gestortienda;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class ConexionBBDD implements BaseDatosTienda {  // Establece la conexi�n con la base de datos MySQL
	
	public List<Prendas> crearConexion() {
		
		try {
			
			//PASO 1: CREAR CONEXI�N
			
			Connection miConex=DriverManager.getConnection("jdbc:mysql://localhost:3306/prendas","root","olga1234");
			
			
			//PASO 2: CREAR OBJETO STATEMENT
			
			Statement miStatem=miConex.createStatement();
			
			
			//PASO 3: EJECUTAR SQL
			
			ResultSet miRes = miStatem.executeQuery("SELECT * FROM prendas");
			
			
			//PASO 4: RECORRER EL RESULTSET			
			
			List<Prendas> prendas=new ArrayList<Prendas>();		
			
			
			while (miRes.next()) {
				
				prendas.add(new Prendas(
						
						miRes.getInt("id") + "" + 
						TipoPrenda.valueOf(miRes.getString("tipo")) + "" + 
						miRes.getString("color") + "" + 
						miRes.getString("talla") + "" +
						miRes.getString("descrip") + "" +
						miRes.getString("url") + "" ));
				}
				
				return prendas;
				
			
		} catch (SQLException e) {
			
			System.out.println("No conecta con la base de datos");
			
			e.printStackTrace();			
			
		}
		
		return null;
	}
}
