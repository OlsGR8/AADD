package gestortienda;

import java.util.ArrayList;

public class Prendas {
	
	private int id;	
	
	private TipoPrenda tipo;
	
	private String color;
	
	private String talla;
	
	private String descrip;
	
	private String url;
	
	private static int nextId=1;	
	
	
		
	public Prendas(int id, TipoPrenda tipo, String color, String talla, String descrip, String url) {			
		
		this.id = 100000 + nextId++;
		
		this.tipo = tipo;
		
		this.color = color;
		
		this.talla = talla;
		
		this.descrip = " ";
		
		this.url = url;		
	
	}	

	
	// GETTERS Y SETTERS :


	public int getId() { return id; }

	public void setId(int id) { this.id = id;	}

	public TipoPrenda getTipo() { return tipo; }

	public void setTipo(TipoPrenda tipo) { this.tipo = tipo; }

	public String getColor() { return color; }

	public void setColor(String color) { this.color = color; }

	public String getTalla() { return talla;	}

	public void setTalla(String talla) { this.talla = talla; }

	public String getDescrip() { return descrip; }

	public void setDescrip(String descrip) { this.descrip = descrip; }

	public String getUrl() { return url; }

	public void setUrl(String url) { this.url = url; }
		
	
	@Override
	public String toString() {
		
		return 	"id=" + id +
				", tipo=" + tipo +
				", color=" + color +
				", talla=" + talla +
				", descrip=" + descrip +
				", url=" + url + "";
	}
	
	
	public String dameDatos() {

		return id + "Tipo de prenda = " + tipo + color + talla + descrip + url;		

	}
	

    public String toXml() {
        return  "\t<articulo id=\" " + id + "\">\r\n" +
				"\t\t<tipo>" + tipo + "</tipo>\r\n" +
				"\t\t<color>" + color + "</color>\r\n" +
				"\t\t<talla>" + talla + "</talla>\r\n" +
				"\t\t<descrip>" + descrip + "</descrip>\r\n" +
				"\t\t<url>" + url + "</url>\r\n" +
				"\t</articulo>\r\n";
    }
    
        		        		
    public String toTxt() {
        return  "ID: " + id + "\r\n" +
                "Tipo: " + tipo + "\r\n" +
                "Color: " + color + "\r\n" +
                "Talla: " + talla + "\r\n" +
                "Descripci�n: " + descrip +
                "Url: " + url;
    }
    

    
}


