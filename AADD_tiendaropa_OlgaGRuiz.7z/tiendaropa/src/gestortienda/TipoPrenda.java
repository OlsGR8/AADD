package gestortienda;

public enum TipoPrenda {
	
	Chaqueta, 
	
	Camiseta, 
	
	Camisa,
	
	Jersey, 
	
	Sudadera, 
	
	Pantalon,
	
	RopaInterior, 
	
	Calcetines, 
	
	Calzado;	

}
