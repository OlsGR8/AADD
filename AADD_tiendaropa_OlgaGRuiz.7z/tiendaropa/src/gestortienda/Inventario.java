package gestortienda;

import java.io.Serializable;
import java.util.*;

import gestortienda.Prendas;

//import gestortienda.TipoPrenda;


public class Inventario implements Iterable<Prendas> {	
	
		
		static ArrayList<Prendas> listado=new ArrayList<Prendas>();		
			
		static String [] color = { "Rojo", "Verde", "Azul", "Rosa", "Amarillo", "Marr�n", "Morado", "Naranja", "Gris", "Blanco", "Negro"};
		
		static ArrayList<String> color1 = new ArrayList<String>();
		
		static String [] talla = { "XS", "S", "M", "L", "XL"};
		
		static ArrayList<String> lista1 = new ArrayList<String>();
		
		static String [] tipo = {"Chaqueta", "Camiseta", "Camisa", "Jersey", "Sudadera", "Pantal�n", "Ropa interior", "Calcetines", "Calzado"};
		
		static ArrayList<String> tipo1 = new ArrayList<String>();
		
		
		public Inventario(String color, String talla) { 		
			
			Serializable listado= color.indexOf(color) + talla.indexOf(talla);

		}		
		

		public static void main(String [] args) throws Exception {
			
			listado.addAll(listado);
			
			
			Prendas [] listado = new Prendas [100];
			
			try {
				
				//for (int i=0; i<listado.length; i++) {
				for(Prendas prendas: listado) {
					
					System.out.println (listado.length + " - TIPO: "+ tipo.length + " - COLOR: " + color.toString() + " - TALLA: " + talla.toString());
				}
			
			}catch (Exception e) {				
				e.printStackTrace();
			}
		}			

		@Override
		public Iterator<Prendas> iterator() {

			return null;
		}		    
	}



//----------------------------------------------------------------------------------------------------

	/*	Iterator<String> iterador = color1.iterator();	

	while(iterador.hasNext()) {
		
		//System.out.println(iterador.next());		
			
			System.out.println(iterador.next().dameDatos());				
	}
	*/

	/*

	int [] lista = new int [100];

	for (int i=0; i<talla.length; i++) {
		
//		talla [i]=(int) (Math.random());
		
		System.out.println (i); */

	/*	for(String cadena: tipo) {

	//System.out.println (cadena);

	for(String cadena1: color) {

//		System.out.println (cadena1);

			for(String cadena2: talla) {
		
		//	System.out.println (cadena2);	
				
				
			}				
	
//----------------------------------------------------------------------------------------------------	
	
	@SuppressWarnings("null")
	public static void main(String[] args) {
		
		Collection<String> color=null;
		Collection<String> talla=null;
		
		try {
		for(int i=0; i<100; i++) {
			List <String> listado = new ArrayList<String>(Stream.concat(color.stream(), talla.stream()).collect(Collectors.toList()));
		//	List <String> listado1 = Stream.concat(color.stream(), talla.stream()).collect(Collectors.toList());
		//	listado=listado1;
			
			System.out.println(listado);
		} 
		
		
			
		}catch (Exception e) {

		}
	

	//ListUtils.union(color,talla);
	


/*	public static void combinaDatos() throws Exception {
		
		ArrayList<String> array3=new ArrayList<String>();
		
		for(int i=0; i<100; i++) {
			
			array3.add(color.concat(color)+talla.concat(talla));					

		}
		
		System.out.println(array3);
	}
*/
	
//----------------------------------------------------------------------------------------------------
	
	/*public ArrayList<Prendas> getPrendas() {
				
		prendas=new ArrayList<Prendas>();
					
		return prendas;	
	}	*/
	
//----------------------------------------------------------------------------------------------------
	
   // private static List<String> crearLista() {
	
		//ArrayList<Prendas> listado= prendas.getPrendas();
	
      //  List<String> listado = new ArrayList<String>(); }
	

//----------------------------------------------------------------------------
	
	
 /*   private static void crearArchivoXml() {

    	new File("archivos").mkdir();
    	
        File salida = new File("archivos\\inventario.xml");

        String cabeceraXml = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";

        String etiqApertura = "<articulos>";
        
        String etiqCierre = "</articulos>";

        try {

            BufferedWriter writeSalida = new BufferedWriter(new FileWriter(salida));

            writeSalida.write(cabeceraXml + "\r\n");
            
            writeSalida.write(etiqApertura + "\r\n");
            

            for (int i = 1; i <= 100; i++) {

            	writeSalida.write(crearArticulo(i) + "\r\n");
            }

            writeSalida.write(etiqCierre);

            writeSalida.close();

        } catch (IOException e) {

            System.out.println("Se ha producido un error al intentar escribir en el archivo xml");

        }
    }*/
    
  //----------------------------------------------------------------------------    
 
  /*  private static String crearArticulo(int idPrendas) {

        Prendas articulo = new Prendas(
        		
        		idPrendas,
        		
                TipoPrenda.values()[(int)azar(TipoPrenda.values().length)],
                
                color.get((int)azar(color.size())),
                
                talla.get((int)azar(talla.size())),
                
                descrip
                
               // url.get(????????) // Crear una url por imagen 
                
        		);
 
        return  articulo.toXml();

        
    }  */
    
    
  /*  private static String crearArticulo(int i) {
		
		return null;
	}*/

 //----------------------------------------------------------------------------
    
  /*  // Devuelve un n�mero entero aleatorio entre 0 y size-1, 
    // para vincular de forma aleatoria los atributos para cada art�culo

	private static long azar(long size) {

        return (long) (Math.random() * (size));
    } */
    

//----------------------------------------------------------------------------
	
	/*public void vincularUrl() {

		

	}*/
		
//----------------------------------------------------------------------------------------------------		
		


	
	

