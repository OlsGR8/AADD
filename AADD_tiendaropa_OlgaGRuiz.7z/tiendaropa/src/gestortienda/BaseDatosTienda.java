package gestortienda;

import java.util.List;

public interface BaseDatosTienda {
	
	List<Prendas> crearConexion();

}
